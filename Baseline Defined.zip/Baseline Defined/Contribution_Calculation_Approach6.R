#####################Libraries######################################
rm(list = ls())
library(rstudioapi)
library(data.table)
library(dplyr)
library(lubridate)
library(openxlsx)
library(readxl)
library(zoo)

###################FUNCTIONS#################
#This code calculates the contributions for a log-log TPO Model.
#Baseline sales are calculated according to the baseline conditions specified.
#Individual contributions are calculated on the incremental sales


read_csv_file<-function(path){
  data = read.csv(path) 
  return(data)
}

#Reads the baseline file and returns config details along with the baseline parameters
read_basline_data<-function(path){
  baseline = read_excel(path,sheet = "Baseline")
  config = read_excel(path,sheet = "Config")
  return (list(baseline=baseline,config=config))
}

#Predict sales using y=exp(Intercept+x1b1+x2b2..)
predict_sales <- function(df_Coeff,df_data){
  r = 0
  for ( i in df_Coeff$Parameters){
    if (i=="Intercept"){
      r = r+df_Coeff$Value[df_Coeff$Parameters==i]
    }
    else{
      r= r+df_data[i]*df_Coeff$Value[df_Coeff$Parameters==i]
    }
  }
  r = exp(r)
  colnames(r)<-c("Predicted_sales")
  df_data<- cbind(df_data,r)
  return (df_data)
}


#Create baseline dataframe based on the condtitions specified in baseline_data
#If the action specified is ROlling max: Max value in the last `n` weeks based on "value" specified.
#If the action specified is Set average: Baseline value is equal to the "Value" specified.
#If the action specified is As is: Data for the parameter is taken as is.
#Variables not specified in the baseline file will be set to 0.
#df_Coeff : Parameters and COefficients in the model
#df_Data : Weekly Data
#baseline_data : Baseline Conditions specified in the input.
create_baseline_df<-function(df_Coeff,df_data,baseline_data){
  baseline_df = data.table()
  for(i in baseline_data$Parameters){
    action = baseline_data[baseline_data$Parameters==i,]$Action
    if(action=="Set Average"){
      value = baseline_data[baseline_data$Parameters==i,]$Value
      baseline_df[,paste(i)] = value
    }
    if(action=="As is"){
      baseline_df[,paste(i)] = df_data[[i]]
    }
    if(action=="Rolling Max"){
      value = baseline_data[baseline_data$Parameters==i,]$Value
      WW_model_Data <- df_data %>% mutate(Final_baseprice = rollapply(df_data[i],width = value,FUN = max,na.rm = T,partial = T,align = c("right")))
      WW_model_Data$Final_baseprice[WW_model_Data$Final_baseprice == -Inf] <- WW_model_Data$median_baseprice[WW_model_Data$Final_baseprice == -Inf]
      WW_model_Data$Final_baseprice[is.na(WW_model_Data$Final_baseprice)] <- WW_model_Data$wk_sold_avg_price_byppg[is.na(WW_model_Data$Final_baseprice)]
      baseline_df[,paste(i)]<-WW_model_Data$Final_baseprice
      
    }
    
  }
  #other_paras : Parameters not specified in  baseline condition.
  other_params = setdiff(df_Coeff$Parameters,baseline_data$Parameters)
  
  for(i in other_params){
    
    if(i!="Intercept"){
      baseline_df[,paste(i)] = 0
    }
    
  }
  return(baseline_df)
}




#Predict sales using y=exp(Intercept+x1b1+x2b2..)
predict_baseline_sales <- function(df_Coeff,df_data){
  r = 0
  df_data = data.frame(df_data)
  for ( i in df_Coeff$Parameters){
    if (i=="Intercept"){
      r = r+df_Coeff$Value[df_Coeff$Parameters==i]
    }
    else{
      r= r+df_data[i]*df_Coeff$Value[df_Coeff$Parameters==i]
    }
  }
  r = exp(r)
  colnames(r)<-c("Predicted_baseline_sales")
  df_data<- cbind(df_data,r)
  return (df_data)
}

#Incremental sales = Predicted Sales - Predicted Baseline Sales
incremental_calulations<- function(df_data){
  df_data$incremental_predicted <- df_data$Predicted_sales - df_data$Predicted_baseline_sales
  return(df_data)
}




#Calculate contributions on the incremental value
#data: weekly data ; parameters : model coefficients and values; baseline: baseline data
get_raw_contributions_2<-function(data,parameters,baseline){
  data = data.table(data)
  parameters = data.table(parameters)
  baseline = data.table(baseline)
  columns_to_be_run = parameters$Parameters[parameters$Parameters!="Intercept"]
  pred_xb = 0
  data$Intercept = 1
  baseline$Intercept = 1
  ###Calculate x1b1+x2b2....
  for(i in parameters$Parameters)
  {
    pred_xb = pred_xb + data[[i]] *   parameters$Value[parameters$Parameter==i]
    
  }
  
  rc_sum = 0
  abs_sum = 0
  
  for(i in parameters$Parameters)
  {
    rc = 0
    rc = exp(pred_xb) - exp( pred_xb - (data[[i]] *   parameters$Value[parameters$Parameter==i]) +
                               (baseline[[i]] *   parameters$Value[parameters$Parameter==i])  )
    data[,tmp := rc]
    setnames(data,"tmp",paste0(i,"_rc"))
    
    rc_sum = rc_sum + rc # Sum of raw contributions
    abs_sum = abs_sum + abs(rc) # Absolute Sum of raw contributions
    
    
  }
  
  y_b_s = data$incremental_predicted - rc_sum
  #Redistribute Raw Contribution
  new_df = data.table()
  dist_df = data.table()
  for(i in parameters$Parameters)
  {
    
    rc = data[,get(paste0(i,"_rc"))]
    fc = rc + ( abs(rc)/abs_sum) * y_b_s
    new_df[,tmp := fc]
    dist_df[,tmp := fc]
    setnames(new_df,"tmp",paste0(i,'_distributed',sep=''))
    setnames(dist_df,"tmp",paste0(i,'_distributed',sep=''))
  }
  
  new_df = data.frame(new_df) #Stores units distributed value;units%. WIll be used in other functions  
  dist_df = data.frame(dist_df) #Stores units distributed value

  is.nan.data.frame <- function(x)
    do.call(cbind, lapply(x, is.nan))
  new_df[is.nan(new_df)] <- 0
  dist_df[is.nan(dist_df)] <- 0

  new_df$Date<-data$Date
  new_df$Predicted_sales<-data$Predicted_sales
  new_df$Predicted_baseline_sales<-baseline$Predicted_baseline_sales
  new_df$incremental_predicted<-baseline$incremental_predicted
  dist_df$Predicted_baseline_sales<-baseline$Predicted_baseline_sales
  dist_df$incremental_predicted<-baseline$incremental_predicted
  
  new_df$Predicted_sales<-data$Predicted_sales
  units_df = data.table() #Stores Units% value
  new_df <- transform(new_df, baseline_sales_perc = round((Predicted_baseline_sales / Predicted_sales)*100,2))
  units_df$baseline_sales_perc = round((new_df$Predicted_baseline_sales / new_df$Predicted_sales)*100,2)
  for (i in columns_to_be_run){
    units_df[,paste(i,'_sales%',sep='')]=round((new_df[[paste(i,'_distributed',sep='')]]/new_df[["Predicted_sales"]])*100,2)
  }

  summary_sales = get_summary(units_df,columns_to_be_run)
  basline_percen = list("baseline_sales_perc",min(new_df$baseline_sales_perc),max(new_df$baseline_sales_perc), mean(new_df$baseline_sales_perc),median(new_df$baseline_sales_perc),sd(new_df$baseline_sales_perc))
  summary_sales = rbind(summary_sales,basline_percen)
  summary_sales = rapply( summary_sales, f=function(x) ifelse(is.nan(x),0,x), how="replace" )
  summary_sales = rapply( summary_sales, f=function(x) ifelse(is.infinite(x),0,x), how="replace" )
  return(list( Sales_summary = summary_sales , units=units_df,distribution=dist_df))
}


get_summary <-function(temp_data,columns_to_be_run){
  #Summary Details  
  names = c()
  mean_data = c()
  min_data = c()
  max_data = c()
  median_data = c()
  sd_data = c()
  
  index_pos=1
  for (i in columns_to_be_run){
    names[index_pos] = paste(i,'_sales%',sep='')
    mean_data[index_pos] = mean(temp_data[[paste(i,'_sales%',sep='')]])
    min_data[index_pos] = min(temp_data[[paste(i,'_sales%',sep='')]])
    max_data[index_pos] = max(temp_data[[paste(i,'_sales%',sep='')]])
    median_data[index_pos] = median(temp_data[[paste(i,'_sales%',sep='')]])
    sd_data[index_pos] = sd(temp_data[[paste(i,'_sales%',sep='')]])
    index_pos = index_pos+1
  }
  
  summary_sales = data.table(
    'Parameters'= names,
    'Min' = min_data,
    'Max' = max_data,
    'Mean' = mean_data,
    'Median' = median_data,
    "Standard Deviation" = sd_data
  )
  
}


#Get quarter based on the month
get_quarter <-function(x){
  if(x<4){
    return('Q1')
  }
  if(x<7){
    return('Q2')
  }
  if(x<10){
    return('Q3')
  }
  return('Q4')
}

#Get quarterly and yearly units distribution and units distribution%
get_quarterly_data <-function(data,df_Coeff,date_format){
  col_contrib = "incremental_predicted"
  parameters = df_Coeff$Parameters[! df_Coeff$Parameters %in% 'Intercept']
  parameters_dist = paste(parameters,'_distributed',sep='')
  
  subset_data = subset(data,select=parameters_dist)
  if(date_format=='ymd'){
    subset_data$Quarter = sapply(month(ymd(data$Date)),FUN = get_quarter)
    subset_data$Year = year(ymd(data$Date))  
  }else{
    subset_data$Quarter = sapply(month(dmy(data$Date)),FUN = get_quarter)
    subset_data$Year = year(dmy(data$Date))  
  }
  
  subset_data[[paste(col_contrib)]] = data[[col_contrib]]
  subset_data$Predicted_baseline_sales = data$Predicted_baseline_sales
  #Group data by year
  subset_data_yearly = within(subset_data,rm('Quarter'))%>%group_by(Year)%>%summarise_all(sum)
  #Group data by year-quarter
  subset_data = subset_data%>%group_by(Year,Quarter)%>%summarise_all(sum)
  
  parameters_dist = c(parameters_dist,'Predicted_baseline_sales')
  row_sum = rowSums(subset(subset_data,select=parameters_dist))
  rowsum_yearly = rowSums(subset(subset_data_yearly,select=parameters_dist))
  yearly_percentages = data.table()
  quarterly_percentages = data.table()
  quarterly_absolute = data.table()
  yearly_absolute = data.table()
  quarterly_percentages[,paste('Predicted_baseline','_sales%',sep='')]=round(subset_data$Predicted_baseline_sales/row_sum*100,2)
  quarterly_absolute$Predicted_baseline = subset_data$Predicted_baseline_sales
  yearly_percentages[,paste('Predicted_baseline','_sales%',sep='')]=round(subset_data_yearly$Predicted_baseline_sales/rowsum_yearly*100,2)
  yearly_absolute$Predicted_baseline = subset_data_yearly$Predicted_baseline_sales
  #Calculate quarterly and yearly percentages
  for (i in parameters){
    column = paste(i,'_distributed',sep='')
    quarterly_percentages[,paste(i,'_sales%',sep='')] = round(subset_data[[column]]/row_sum*100,2)
    yearly_percentages[,paste(i,'_sales%',sep='')] = round(subset_data_yearly[[column]]/rowsum_yearly*100,2)
    quarterly_absolute[,paste(i,sep='')] = round(subset_data[[column]],2)
    yearly_absolute[,paste(i,sep='')] = round(subset_data_yearly[[column]],2)
  }
  #Pivot data
  yearly_percentages$Year = subset_data_yearly$Year
  yearly_absolute$Year = subset_data_yearly$Year
  subset_data_yearly =  dcast(melt(as.data.table(yearly_percentages),id.vars="Year"),variable~ Year)
  subset_data_yearly_dist =  dcast(melt(as.data.table(yearly_absolute),id.vars="Year"),variable~ Year)
  
  quarterly_percentages$Year_Quarter = paste(subset_data$Year,subset_data$Quarter,sep ='-' )
  quarterly_absolute$Year_Quarter = paste(subset_data$Year,subset_data$Quarter,sep ='-' )
  subset_data=dcast(melt(as.data.table(quarterly_percentages),id.vars="Year_Quarter"),variable~ Year_Quarter)
  subset_data_dist=dcast(melt(as.data.table(quarterly_absolute),id.vars="Year_Quarter"),variable~ Year_Quarter)
  
  return(list(quarterly=subset_data,
              yearly=subset_data_yearly,
              quarterly_dist=subset_data_dist,
              yearly_dist=subset_data_yearly_dist))
}


#Calculate sales distribution.
#Weekly sales = Weekly units* avg weekly price
price_distribution<-function(dist2,df_Coeff,price_val){
  dist2$Price = price_val
  price_df=data.table()
  for (i in df_Coeff$Parameters){
    col = paste(i,'_distributed',sep='')
    
    if (col %in% names(dist2)){
      price_df[,paste(i,'_distributed',sep='')] = dist2[[col]]*dist2$Price
    }    
  }
  price_df[,paste('Predicted_baseline','_distributed',sep='')] = dist2$Predicted_baseline_sales*dist2$Price
  price_per = data.table()
  total_price = rowSums(price_df) #Calculate sum of sales
  for (i in names(price_df)){
    col_name = gsub('_price_distributed','_sales%',i)
    price_per[,col_name] = price_df[[i]]/total_price*100  
    
  }
  
  return(list(price_percentages = price_per , price_for_quarterly= price_df))
  
}

#Get quarterly and yearly sales distribution and sales distribution%
get_quarterly_price_data <-function(data,df_Coeff,date_format){
  parameters = df_Coeff$Parameters[! df_Coeff$Parameters %in% 'Intercept']
  parameters_dist = paste(parameters,'_distributed',sep='')
  
  subset_data = subset(data,select=parameters_dist)
  if(date_format=='ymd'){
    subset_data$Quarter = sapply(month(ymd(data$Date)),FUN = get_quarter)
    subset_data$Year = year(ymd(data$Date))  
  }else{
    subset_data$Quarter = sapply(month(dmy(data$Date)),FUN = get_quarter)
    subset_data$Year = year(dmy(data$Date))  
  }
  
  subset_data$Predicted_baseline_distributed = data$Predicted_baseline_distributed
  #Group data by year
  subset_data_yearly = within(subset_data,rm('Quarter'))%>%group_by(Year)%>%summarise_all(sum)
  #Group data by year-quarter
  subset_data = subset_data%>%group_by(Year,Quarter)%>%summarise_all(sum)
  
  parameters_dist = c(parameters_dist,'Predicted_baseline_distributed')
  row_sum = rowSums(subset(subset_data,select=parameters_dist))
  rowsum_yearly = rowSums(subset(subset_data_yearly,select=parameters_dist))
  quarterly_percentages=data.table()
  yearly_percentages=data.table()
  quarterly_absolute = data.table()
  yearly_absolute = data.table()
  quarterly_percentages[,paste('Predicted_baseline','_sales%',sep='')]=round(subset_data$Predicted_baseline_distributed/row_sum*100,2)
  quarterly_absolute$Predicted_baseline = subset_data$Predicted_baseline_distributed
  yearly_percentages[,paste('Predicted_baseline','_sales%',sep='')]=round(subset_data_yearly$Predicted_baseline_distributed/rowsum_yearly*100,2)
  yearly_absolute$Predicted_baseline = subset_data_yearly$Predicted_baseline_distributed
  #Calculate quarterly and yearly percentages
  for (i in parameters){
    column = paste(i,'_distributed',sep='')
    quarterly_percentages[,paste(i,'_sales%',sep='')] = round(subset_data[[column]]/row_sum*100,2)
    yearly_percentages[,paste(i,'_sales%',sep='')] = round(subset_data_yearly[[column]]/rowsum_yearly*100,2)
    quarterly_absolute[,paste(i,sep='')] = round(subset_data[[column]],2)
    yearly_absolute[,paste(i,sep='')] = round(subset_data_yearly[[column]],2)
  }
  yearly_percentages$Year = subset_data_yearly$Year
  yearly_absolute$Year = subset_data_yearly$Year
  #Pivot Data
  subset_data_yearly =  dcast(melt(as.data.table(yearly_percentages),id.vars="Year"),variable~ Year)
  subset_data_yearly_dist =  dcast(melt(as.data.table(yearly_absolute),id.vars="Year"),variable~ Year)
  
  quarterly_percentages$Year_Quarter = paste(subset_data$Year,subset_data$Quarter,sep ='-' )
  quarterly_absolute$Year_Quarter = paste(subset_data$Year,subset_data$Quarter,sep ='-' )
  subset_data=dcast(melt(as.data.table(quarterly_percentages),id.vars="Year_Quarter"),variable~ Year_Quarter)
  subset_data_dist=dcast(melt(as.data.table(quarterly_absolute),id.vars="Year_Quarter"),variable~ Year_Quarter)
  
  return(list(quarterly=subset_data,
              yearly=subset_data_yearly,
              quarterly_dist=subset_data_dist,
              yearly_dist=subset_data_yearly_dist))
  
}




#################INPUT DATA####################
setwd(paste0(dirname(rstudioapi::getActiveDocumentContext()$path)))


baseline_data = read_basline_data("./baseline.xlsx")$baseline
config = read_basline_data("./baseline.xlsx")$config

model_path = config[config$Parameter=="Model Path",]$Value
data_path = config[config$Parameter=="Data Path",]$Value
df_Coeff = read_csv_file(model_path)
df_data= read_csv_file(data_path)

price = config[config$Parameter=="Weekly Price",]$Value
price_val = df_data[[price]]
date_format = config[config$Parameter=="Date Format",]$Value
output_file = config[config$Parameter=="Output File",]$Value

df_data = predict_sales(df_Coeff,df_data)
Predicted_sales_df = df_data

baselin_df = create_baseline_df(df_Coeff,df_data,baseline_data)
df_baseline_sales_predicted = predict_baseline_sales(df_Coeff,baselin_df)
df_data$Predicted_baseline_sales <- df_baseline_sales_predicted$Predicted_baseline_sales
#################################### Raw Contribution
df_data = incremental_calulations(df_data)
df_baseline_sales_predicted$incremental_predicted = df_data$incremental_predicted

df_baseline_sales_predicted$mean_predicted_baseline_sales = mean(df_baseline_sales_predicted$Predicted_baseline_sales)
df_baseline_sales_predicted$SDEV_predicted_baseline_sales = sd(df_baseline_sales_predicted$Predicted_baseline_sales)
df_baseline_sales_predicted["SDEV_predicted_baseline_sales/mean"] = sd(df_baseline_sales_predicted$Predicted_baseline_sales)/mean(df_baseline_sales_predicted$Predicted_baseline_sales)

############Delta Calculations - (Data- Baseline) for each variable
df_delta=subset(df_data,select=df_Coeff$Parameters[df_Coeff$Parameters !="Intercept"])
for (i in df_Coeff$Parameters){
  if(i!="Intercept"){
    df_delta[i] = df_data[[i]] - df_baseline_sales_predicted[[i]]
    
  }
}

#Get Baseline variables set to "As is". Will be dropped from output sheets
as_is = baseline_data[baseline_data$Action=="As is",]$Parameters



delta_temp=df_delta
delta_temp$Predicted_sales=Predicted_sales_df$Predicted_sales
delta_temp$Predicted_baseline_sales<- df_baseline_sales_predicted$Predicted_baseline_sales
delta_temp$incremental_predicted<- df_baseline_sales_predicted$incremental_predicted
delta_temp$Date = df_data$Date

############Units Distribution
rc_df = get_raw_contributions_2(data = df_data,df_Coeff,df_baseline_sales_predicted)
sales_summary = rc_df$Sales_summary #Summary Data for Units 
distribution = rc_df$distribution #Units Distribution-Weekly
units = rc_df$units #Units Distribution %-Weekly



############Sales Distribution
price_list=price_distribution(distribution,df_Coeff,price_val)
price_percentages = price_list$price_percentages #Sales Distribution %-Weekly 
price_for_quarterly = price_list$price_for_quarterly #Sales Distribution -Weekly 
############Quarterly and Yearly Distributions

distribution$Date = delta_temp$Date
summary_data = get_quarterly_data(distribution,df_Coeff,date_format)
quarterly_data = summary_data$quarterly #Quarterly Units Distribution %
yearly_data = summary_data$yearly #Yearly Units Distribution %
quarterly_dist = summary_data$quarterly_dist #Quarterly Units Distribution
yearly_dist = summary_data$yearly_dist #Yearly Units Distribution 

price_for_quarterly$Date = delta_temp$Date
price_summary = get_quarterly_price_data(price_for_quarterly,df_Coeff,date_format)
price_quarterly= price_summary$quarterly #Quarterly Sales Distribution %
price_yearly= price_summary$yearly #Yearly Sales Distribution %
price_quarterly_dist = price_summary$quarterly_dist #Quarterly Sales Distribution
price_yearly_dist = price_summary$yearly_dist #Yearly Sales Distribution 


if (date_format == 'dmy'){
  common_date = as.Date(delta_temp$Date,format='%d-%m-%Y')  
}else{
  common_date = as.Date(delta_temp$Date,format='%Y-%m-%d')  
}


#Include date in all tables
df_delta$Date = common_date
distribution$Date = common_date
units$Date = common_date
Predicted_sales_df$Date = common_date
df_baseline_sales_predicted$Date = common_date
price_for_quarterly$Date = common_date

#Remove distributed from column names
colnames(distribution) = gsub('_distributed','',names(distribution))
colnames(price_for_quarterly) = gsub('_distributed','',names(price_for_quarterly))
colnames(units) = gsub('sales','units',names(units))

##Remove "As-is" variables from the outputs
distribution = distribution[,!names(distribution)%in% as_is]
price_for_quarterly = data.frame(price_for_quarterly)[,!names(price_for_quarterly)%in% as_is]
units = data.frame(units)[,!names(units)%in% as_is]

as_is_yearly = paste(as_is,'_sales%',sep='')

yearly_dist = yearly_dist[!yearly_dist$variable%in% as_is_yearly]
yearly_data = yearly_data[!yearly_data$variable%in% as_is_yearly]
quarterly_dist = quarterly_dist[!quarterly_dist$variable%in% as_is_yearly]
quarterly_data = quarterly_data[!quarterly_data$variable%in% as_is_yearly]

price_yearly_dist = price_yearly_dist[!price_yearly_dist$variable%in% as_is_yearly]
price_yearly = price_yearly[!price_yearly$variable%in% as_is_yearly]
price_quarterly_dist = price_quarterly_dist[!price_quarterly_dist$variable%in% as_is_yearly]
price_quarterly = price_quarterly[!price_quarterly$variable%in% as_is_yearly]

list_of_datasets <- list("Predicted Sales" = Predicted_sales_df, 
                         "Baseline_Sales" = df_baseline_sales_predicted,
                         "Distribution" = distribution,
                         "Sales Distribution" = price_for_quarterly,
                         "Units share%" = units,
                         "Quarterly Units" = quarterly_dist,
                         "Quarterly Units%" = quarterly_data,
                         "Yearly Units" = yearly_dist,
                         "Yearly Units%" =  yearly_data,
                         "Yearly Sales" = price_yearly_dist,
                         "Yearly Sales%" = price_yearly,
                         "Quarterly Sales" = price_quarterly_dist,
                         "Quarterly Sales%" = price_quarterly
)

write.xlsx(list_of_datasets, file = output_file,append=TRUE)



