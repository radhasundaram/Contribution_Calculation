rm(list = ls())
library(rstudioapi)
library(data.table)
library(dplyr)
library(lubridate)
library(openxlsx)
library(readxl)
library(zoo)
library(crayon)


#This code calculates the contributions for a log-log TPO Model.
#Baseline sales are calculated according to the baseline variables specified.
#Individual contributions are calculated seperately for Baseline variables and Impact Variables

setwd(paste0(dirname(rstudioapi::getActiveDocumentContext()$path)))
###INPUT
config_path = "./config.csv"

###NO CHANGES TO BE MADE FROM HERE
config = fread(config_path)

data_path = config[config$Variable == "Data File",]$Value
actual_price = config[config$Variable == "Weekly Price",]$Value
date_format = config[config$Variable == "Date Format",]$Value
output_path = config[config$Variable == "Output File",]$Value

data = read_xlsx(data_path,sheet = "Data")
setDT(data)

coef = read_xlsx(data_path,sheet = "Coeff")
setDT(coef)

base = read_xlsx(data_path,sheet = "Baseline")




price = data[[actual_price]]

#Price Distribution = Units Distribution* Weekly Price
price_distribution<-function(dist2,price_val){
  price_df=data.table()
  for (i in names(dist2)){
    price_df[,i] = dist2[[i]]*price_val
  }
  print(price_df)
  price_per = data.table()
  total_price = rowSums(price_df) #Calculate sum of sales
  for (i in names(price_df)){
    col_name = paste(i,'price%',sep='')
    price_per[,paste(col_name,sep='')] = price_df[[i]]/total_price*100  
    
  }
  
  return(list(price_percentages = price_per , price_for_quarterly= price_df))
  
}

#Get quarter based on the month
get_quarter <-function(x){
  if(x<4){
    return('Q1')
  }
  if(x<7){
    return('Q2')
  }
  if(x<10){
    return('Q3')
  }
  return('Q4')
}

get_quarterly_data <-function(data,date_format,date){
  column_names = names(data)
  if(date_format=='ymd'){
    data$Quarter = sapply(month(ymd(date)),FUN = get_quarter)
    data$Year = year(ymd(date))  
  }else{
    data$Quarter = sapply(month(dmy(date)),FUN = get_quarter)
    data$Year = year(dmy(date))  
  }
  #Group data by year
  subset_data_yearly = within(data,rm('Quarter'))%>%group_by(Year)%>%summarise_all(sum)
  #Group data by year-quarter
  subset_data = data%>%group_by(Year,Quarter)%>%summarise_all(sum)
  
  
  row_sum = rowSums(subset(subset_data,select = column_names))
  print(1)
  rowsum_yearly = rowSums(subset_data_yearly)
  yearly_percentages = data.table()
  quarterly_percentages = data.table()
  quarterly_absolute = data.table()
  yearly_absolute = data.table()
  
  #Calculate quarterly and yearly percentages
  for (i in column_names){

    quarterly_percentages[,paste(i,'_sales%',sep='')] = round(subset_data[[i]]/row_sum*100,2)
    yearly_percentages[,paste(i,'_sales%',sep='')] = round(subset_data_yearly[[i]]/rowsum_yearly*100,2)
    quarterly_absolute[,paste(i,sep='')] = round(subset_data[[i]],2)
    yearly_absolute[,paste(i,sep='')] = round(subset_data_yearly[[i]],2)
  }
  #Pivot data
  yearly_percentages$Year = subset_data_yearly$Year
  yearly_absolute$Year = subset_data_yearly$Year
  subset_data_yearly =  dcast(melt(as.data.table(yearly_percentages),id.vars="Year"),variable~ Year)
  subset_data_yearly_dist =  dcast(melt(as.data.table(yearly_absolute),id.vars="Year"),variable~ Year)
  
  quarterly_percentages$Year_Quarter = paste(subset_data$Year,subset_data$Quarter,sep ='-' )
  quarterly_absolute$Year_Quarter = paste(subset_data$Year,subset_data$Quarter,sep ='-' )
  subset_data=dcast(melt(as.data.table(quarterly_percentages),id.vars="Year_Quarter"),variable~ Year_Quarter)
  subset_data_dist=dcast(melt(as.data.table(quarterly_absolute),id.vars="Year_Quarter"),variable~ Year_Quarter)
  
  return(list(quarterly=subset_data,
              yearly=subset_data_yearly,
              quarterly_dist=subset_data_dist,
              yearly_dist=subset_data_yearly_dist))
}





data[,Intercept := 1]
#Calculate predicted sales using y=exp(x1b1+x2b2....)
predicted_val = 0
for(i in coef$Variable)
{
  predicted_val = predicted_val + data[,get(i)] * as.numeric(coef[Variable==i,"Value"])
}

data[,predicted := exp(predicted_val)]

#Get base variables and impact variables
base_var = base$Variable
base_var = c("Intercept",base_var)
impact_var = coef$Variable[!coef$Variable %in% base_var]

base_val = 0 #x1b1+x2b2.. for base variables
impact_val = 0 #x1b1+x2b2.. for impact variables
for(i in coef$Variable){
  if(i %in% base_var){
    base_val = base_val + data[,get(i)] * as.numeric(coef[Variable==i,"Value"])  
  }else{
    impact_val = impact_val + data[,get(i)] * as.numeric(coef[Variable==i,"Value"])
  }
}

data[,baseline_contribution := exp(base_val) ]
data$incremental_contribution = data[,predicted] - data[,baseline_contribution]
#Calculate raw contribution for impact variables
row_sum =0 
abs_sum = 0
for(i in impact_var){
    var_val = base_val+impact_val - data[,get(i)] * as.numeric(coef[Variable==i,"Value"])
    tmp = exp(base_val+impact_val) - exp(var_val)
    data[,tmp := tmp]
    setnames(data,"tmp",paste0(i,"_contribution_impact"))
    row_sum = row_sum + tmp
    abs_sum = abs_sum + abs(tmp)
    
}

y_b_S = data$incremental_contribution - row_sum
#Redistribute raw contribution for impact variables
impact_contribution = data.table()
for(i in  impact_var){
  i = paste(i,"_contribution_impact",sep="")
  val1 = abs(data[,get(i)]) / abs_sum
  tmp = data[,get(i)] + val1*y_b_S
  impact_contribution[,tmp := tmp]
  setnames(impact_contribution,"tmp",i)
}




#Base distribution (sequential)

base_rc = data[,"Intercept"] * as.numeric(coef[Variable=="Intercept","Value"])

impact_contribution[,tmp_var := exp(base_rc)]
setnames(impact_contribution,"tmp_var",paste0("Intercept","_contribution_base"))


for( i in base_var[2:length(base_var)])
{
  t = data[,get(i)] * as.numeric(coef[Variable==i,"Value"]) + base_rc
  t2 = exp(t) - exp(base_rc)
  print(t2)
  impact_contribution[,tmp_var := t2]
  setnames(impact_contribution,"tmp_var",paste0(i,"_contribution_base"))
  base_rc = t
    
}
impact_contribution = data.frame(impact_contribution)
#Set Nan to 0
is.nan.data.frame <- function(x)
  do.call(cbind, lapply(x, is.nan))
impact_contribution[is.nan(impact_contribution)] <- 0

##Calculate Price Distribution
price_for_quarterly = price_distribution(impact_contribution,price)$price_for_quarterly
units_sum = get_quarterly_data(impact_contribution,'ymd',data$Date)
sales_sum = get_quarterly_data(price_for_quarterly,'ymd',data$Date)

#Assess baseline stabilty
data$mean_predicted_baseline_sales = mean(data$baseline_contribution)
data$SDEV_predicted_baseline_sales = sd(data$baseline_contribution)
data$CV_predicted_baseline_sales = impact_contribution$SDEV_predicted_baseline_sales/impact_contribution$mean_predicted_baseline_sales

#Remove impact columns and Intercept from data 
cols = names(data)[grepl('_impact',names(data))]
cols = c('Intercept',cols)
data[,(cols):=NULL]

if (date_format == 'dmy'){
  common_date = as.Date(data$Date,format='%d-%m-%Y')  
}else{
  common_date = as.Date(data$Date,format='%Y-%m-%d')  
}

impact_contribution$Date = common_date
price_for_quarterly$Date = common_date

files = list()
files[["Predicted_Sales"]] = data
files[["Distribution"]] = impact_contribution
files[["Sales_Distribution"]] = price_for_quarterly

##Quarterly and Yearly Units Distribution
files[["Quarterly Units"]] = units_sum$quarterly_dist
files[["Quarterly Units%"]] = units_sum$quarterly
files[["Yearly Units"]] = units_sum$yearly_dist
files[["Yearly Units%"]] = units_sum$yearly

##Quarterly and Yearly Sales Distribution
files[["Quarterly Sales"]] = sales_sum$quarterly_dist
files[["Quarterly Sales%"]] = sales_sum$quarterly
files[["Yearly Sales"]] = sales_sum$yearly_dist
files[["Yearly Sales%"]] = sales_sum$yearly


write.xlsx(files, file = output_path,append=TRUE)






